package Game;
import java.awt.event.*;
public class InputHandler extends KeyAdapter{
    GamePanel panel;
    public InputHandler(GamePanel panel){
        this.panel=panel;

    }
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        int newX = panel.jerry.getx();
        int newY = panel.jerry.gety();
    
        if (key == KeyEvent.VK_LEFT) {
            newX = Math.max(0, newX - 5);
        } else if (key == KeyEvent.VK_RIGHT) {
            newX = Math.min(765, newX + 5);
        } else if (key == KeyEvent.VK_UP) {
            newY = Math.max(0, newY - 5);
        } else if (key == KeyEvent.VK_DOWN) {
            newY = Math.min(540, newY + 5);
        }
    
        // Check for wall collision
        if (panel.canMove(newX, newY)) {
            panel.jerry.setx(newX);
            panel.jerry.sety(newY);
        }
    }
}