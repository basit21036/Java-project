package Game;
public class Tom extends Character{
    private int speed = 1;
    private int detectionrange = 150;
    private MusicPlayer musicPlayer; // Object for playing music
    private MusicPlayer impactMusicPlayer;
    private boolean isPlayingBackgroundMusic = false;

    public Tom(int x, int y) {
       super(x,y);
        this.musicPlayer = new MusicPlayer("temp\\Game\\Pvoice.wav"); // Initialize in constructor
        this.impactMusicPlayer = new MusicPlayer("C:\\Game final\\Pvoice.wav");
        this.isPlayingBackgroundMusic = false;
    }
    public void moveRandomly() {
        if (Math.random() < 0.02) { // 2% chance to change direction
            dx = (int) (Math.random() * 7) - 3; // Random speed between -3 and 3
            dy = (int) (Math.random() * 7) - 3;
        }
    }

    public void chaseJerry(Jerry jerry) {
        // Calculate distance to Jerry
        double distance = Math.sqrt(Math.pow(x - jerry.x, 2) + Math.pow(y - jerry.y, 2));

        if (distance <= detectionrange) {
            dx = Integer.compare(jerry.x, x) * speed;
            dy = Integer.compare(jerry.y, y) * speed;
            if (!isPlayingBackgroundMusic) {
                playBackgroundMusic();
            }
        }
    }

    public boolean collidesWith(Jerry jerry) {
        // Simple collision detection (distance < 20 pixels)
        double distance = Math.sqrt(Math.pow(x - jerry.x, 2) + Math.pow(y - jerry.y, 2));
        if (distance < 20) {
            playImpactSound();
            return true;
        }
        return false;
    }

    public void move(GamePanel panel) {
        this.moveRandomly();
        int newX = x + dx;
        int newY = y + dy;
        newX = Math.max(0, Math.min(765, newX)); // 800 - 20 (Tom size)
        newY = Math.max(0, Math.min(510, newY)); // 600 - 20

        if (panel.canMove(newX, newY)) {  // Check wall collision
            x = newX;
            y = newY;
        } else {
            // Change direction if hitting a wall
            dx = (int) (Math.random() * 7) - 3; // Random new direction
            dy = (int) (Math.random() * 7) - 3;
        }
    }

    // Method to play background music
    public void playBackgroundMusic() {
        if (musicPlayer != null && !musicPlayer.isPlaying()) {
            musicPlayer.play();
            isPlayingBackgroundMusic = true;
        }
    }

    // Method to stop background music
    public void stopBackgroundMusic() {
        if (musicPlayer != null && musicPlayer.isPlaying()) {
            musicPlayer.stop();
            isPlayingBackgroundMusic = false;
        }
    }

    // Method to play impact sound
    public void playImpactSound() {
        if (impactMusicPlayer != null) {
            // Stop background music
            stopBackgroundMusic();
            impactMusicPlayer.play(); // Play the impact sound
            // Create a timer to restart the background music after the impact sound finishes
            new java.util.Timer().schedule(
                    new java.util.TimerTask() {
                        @Override
                        public void run() {
                            impactMusicPlayer.stop();
                            impactMusicPlayer.reset();
                            // Restart background music
                            playBackgroundMusic();
                        }
                    },
                    1000 // Delay in milliseconds (adjust as needed)
            );
        }
    }

    public void setDetectionRange(int detectionRange) {
        this.detectionrange = detectionRange;
    }
}
