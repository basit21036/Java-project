package Game; // Added the package declaration
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.*;
public class MusicPlayer {
    private Clip clip;
    private boolean isPlaying = false; // Added to track play state

    public MusicPlayer(String filePath) {
        try {
            // Create a File object representing the audio file.
            File audioFile = new File(filePath);
            // Check if the audio file exists.
            if (!audioFile.exists()) {
                System.err.println("Error: Audio file not found at " + filePath);
                return; // Exit if file not found to prevent further errors.
            }
            // Create an AudioInputStream from the file.  This is a stream of audio data.
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);
            // Get a Clip object, which is used to play audio.
            clip = AudioSystem.getClip();
            // Open the Clip, associating it with the audio stream.  This prepares the clip for playback.
            clip.open(audioStream);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            // Catch exceptions that may occur during audio file processing.
            System.err.println("Error loading or playing audio: " + e.getMessage());
            // Consider logging the error or throwing a RuntimeException if the error is critical.
        }
    }

    public void play() {
        // Check if the clip is valid and not already playing.
        if (clip != null && !isPlaying) {
            clip.start(); // Start playing the audio.
            isPlaying = true; // Update the playing state.
        }
    }

    public void stop() {
        // Check if the clip is valid and currently playing.
        if (clip != null && isPlaying) {
            clip.stop(); // Stop playing the audio.
            isPlaying = false; // Update the playing state.
        }
    }

    public void reset() {
        // Check if the clip is valid.
        if (clip != null) {
            clip.setMicrosecondPosition(0); // Reset the audio to the beginning.
        }
    }

    public void close() {
        // Check if the clip is valid.
        if (clip != null) {
            clip.close(); // Close the clip, releasing system resources.
            isPlaying = false; // Also reset the playing state
        }
    }

    public boolean isPlaying() {
        return isPlaying;
    }
}