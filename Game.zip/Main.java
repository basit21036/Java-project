package Game;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Main {
    public static void main(String[] args) {
        // Create main frame
        JFrame frame = new JFrame("TOM AND JERRY MAZE GAME");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        // Create CardLayout and parent panel
        final CardLayout cardLayout = new CardLayout();
        final JPanel cardPanel = new JPanel(cardLayout);

        // ----------- Start Panel -----------
        JPanel startPanel = new BackgoundImagepanel("background1.png");
        startPanel.setLayout(new GridBagLayout());
        JButton startButton = new JButton("Start Game");
        startButton.setFont(new Font("Arial", Font.BOLD, 32));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        startPanel.add(startButton, gbc);
        // ----------- Game Panel ------------
        final GamePanel gamePanel = new GamePanel();
        //Add both panels to card layout
        cardPanel.add(startPanel, "Start");
        cardPanel.add(gamePanel, "Game");

        // Button action to switch cards and play music
        
        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "Game");
                gamePanel.startGame();
MusicPlayer backgroundMusic = new MusicPlayer("temp\\Game\\Level_Up.wav"); //  Make sure the path to your audio file is correct.
        backgroundMusic.play();
                gamePanel.requestFocusInWindow(); // Make sure key input works
            }
        });

        // Add cardPanel to frame and show
        frame.add(cardPanel);
        frame.setVisible(true);
    }
}

class BackgoundImagepanel extends JPanel {
    private Image backgroundImage;

    public BackgoundImagepanel(String imagePath) {
        try {
            backgroundImage = new ImageIcon(getClass().getResource(imagePath)).getImage();
        } catch (Exception e) {
            System.out.println("Background image not found: " + imagePath);
        }
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
    }
}
