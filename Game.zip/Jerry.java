package Game;
public class Jerry extends Character {
   
    public Jerry(int x, int y) {
        super(x,y);
    }
public void move(){
   this.setx(this.getx()+dx);
   this.sety(this.gety()+dy);
}
}