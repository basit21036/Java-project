package Game;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
public class GamePanel extends JPanel implements ActionListener{
    Timer timer;//For delay
    Tom tom1,tom2,tom3,tom4;//Refference for Tom Character
    Jerry jerry;//Refference for Jerry
    boolean gameOver=false;//Check is Game over or not
    Image jerrImage;
    Image tomImage;
    Image Back;
    boolean wingame=false;
    private ArrayList<Point> cheesePositions;
private Image cheeseImage;
private int cheeseEaten = 0;
  private ArrayList<Rectangle> walls;
    public GamePanel(){
        this.setFocusable(true);
        this.setBackground(Color.BLACK);
        this.setPreferredSize(new Dimension(800,600));
        this.addKeyListener(new InputHandler(this));
        Back=new ImageIcon(getClass().getResource("Background.png")).getImage();
        tom1=new Tom(600,20);
        tom2=new Tom(300,300);
        tom3=new Tom(250,10);
        tom4=new Tom(250,400);
        jerry=new Jerry(100,100);
        timer=new Timer(20,this);
        walls = new ArrayList<>();
        jerrImage = new ImageIcon(getClass().getResource("Jerry.png")).getImage();
       tomImage=new ImageIcon(getClass().getResource("Tom.png")).getImage();
        createMaze();
        cheeseImage = new ImageIcon(getClass().getResource("Cheese.png")).getImage();
cheesePositions = new ArrayList<>();
   createcheese();

    }
    public void createcheese(){
         cheesePositions.add(new Point(200, 200));
cheesePositions.add(new Point(600, 100));
cheesePositions.add(new Point(20, 200));
cheesePositions.add(new Point(400, 500));
cheesePositions.add(new Point(100, 400));
cheesePositions.add(new Point(700, 300));
cheesePositions.add(new Point(200,110));
cheesePositions.add(new Point(180,80));
cheesePositions.add(new Point(300,200));

    }
 
    public void startGame(){
        timer.start();
    }
    
    private void createMaze() {
        
        walls.add(new Rectangle(50, 0, 10,100 ));      
        walls.add(new Rectangle(50, 130, 10, 30));    
        walls.add(new Rectangle(50, 150, 80, 10));    
        walls.add(new Rectangle(130, 100, 10, 60));    
        walls.add(new Rectangle(140, 100, 100, 10));  
        walls.add(new Rectangle(240, 25, 10, 85));
        walls.add(new Rectangle(340, 0, 10, 100));
        walls.add(new Rectangle(290, 100, 110, 10));
        walls.add(new Rectangle(440, 110, 10, 85));
        walls.add(new Rectangle(640, 90, 10, 100));     
        walls.add(new Rectangle(540, 190, 110, 10));
        walls.add(new Rectangle(540, 190, 10, 150));
        walls.add(new Rectangle(570, 400, 230, 10));
        walls.add(new Rectangle(0, 320, 150, 10));
        walls.add(new Rectangle(150, 320, 10, 60));
        walls.add(new Rectangle(150, 450, 10, 80));
        walls.add(new Rectangle(50, 530, 200, 10));
        walls.add(new Rectangle(350, 350, 10, 100));
        walls.add(new Rectangle(250, 350, 200, 10));
        walls.add(new Rectangle(150, 320, 10, 60));
        walls.add(new Rectangle(550, 440, 10, 110));
        walls.add(new Rectangle(450, 440, 10, 110));
        walls.add(new Rectangle(450, 540, 110, 10));
        
    }
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(Back, 0, 0, getWidth(), getHeight(), null);
        g.setColor(Color.DARK_GRAY);
        
        for (Point cheese : cheesePositions) {
            g.drawImage(cheeseImage, cheese.x, cheese.y, 20, 20, null);
        }
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString("Cheese eaten: " + cheeseEaten, 600, 30);
        for (Rectangle wall : walls) {
            g.fillRect(wall.x, wall.y, wall.width, wall.height);
        }
        if (gameOver) {
            g.setColor(Color.RED);
            g.setFont(new Font("Arial", Font.BOLD, 40));
            g.drawString("GAME OVER!", 300, 300);
        }
        else if(wingame){
              g.setColor(Color.BLUE);
            g.setFont(new Font("Arial", Font.BOLD, 30));
            g.drawString("Jerry Wins", 245, 300);
             g.drawString("Congratulations", 220, 335);
        } else {
            g.drawImage(jerrImage, jerry.getx(), jerry.gety(), 20, 20, null);
            g.drawImage(tomImage, tom1.getx(), tom1.gety(), 20, 30, null);
            g.drawImage(tomImage, tom2.getx(), tom2.gety(), 20, 30, null);
            g.drawImage(tomImage, tom3.getx(), tom3.gety(), 20, 30, null);
              g.drawImage(tomImage, tom4.getx(), tom4.gety(), 20, 30, null);
        }
        }
    public boolean canMove(int x, int y) {
        Rectangle futurePos = new Rectangle(x, y, 20, 30); // Assuming character size is 20x20
        for (Rectangle wall : walls) {
            if (futurePos. intersects(wall)) {
                return false; // Collision detected
            }
        }
        return true; // No collision
    }
    public void actionPerformed(ActionEvent e){
        if (!gameOver) {
            jerry.move();
            java.util.Iterator<Point> it = cheesePositions.iterator();
while (it.hasNext()) {
    Point cheese = it.next();
    Rectangle cheeseRect = new Rectangle(cheese.x, cheese.y, 20, 20);
    Rectangle jerryRect= new Rectangle(jerry.getx(), jerry.gety(), 20, 20);
    if (jerryRect.intersects(cheeseRect)) {
        it.remove();
        cheeseEaten++;
        if(cheesePositions.size()==0){
           wingame=true; 
        }
    }
}
            tom1.move(this);
            tom1.chaseJerry(jerry);
            tom2.move(this);
            tom2.chaseJerry(jerry);
            tom3.move(this);
            tom3.chaseJerry(jerry);
            tom4.move(this);
            tom4.chaseJerry(jerry);
            if (tom1.collidesWith(jerry)) {
                gameOver = true;
            }
            if (tom2.collidesWith(jerry)) {
                gameOver = true;
            }
            if (tom3.collidesWith(jerry)) {
                gameOver = true;
            }
            if (tom4.collidesWith(jerry)) {
                gameOver = true;
            }
            repaint();}
    }}